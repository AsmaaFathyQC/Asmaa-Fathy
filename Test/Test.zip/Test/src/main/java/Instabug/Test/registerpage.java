package Instabug.Test;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.*;

public class registerpage extends pageBase{

	public registerpage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath="/html/body/div[1]/div[2]/div[1]/div/div/div/div[2]/div/div[1]/form/div[5]/a")
	WebElement CreateButton;

	@FindBy(name="firstname")
	WebElement FirstName;
	@FindBy(name="lastname")
	WebElement LastName;
	@FindBy(name="reg_email__")
	WebElement MobNumber;
	@FindBy(name="reg_passwd__")
	WebElement UserPass;
	@FindBy(id="day")
	WebElement Day;
	@FindBy(id="month")
	WebElement Month;
	@FindBy(id="year")
	WebElement Year;
	@FindBy(xpath="(//input[@name='sex'])[1]")
	WebElement Gender;
	@FindBy(name="websubmit")
	WebElement SignUp;
   
	public void click_createbutton() throws InterruptedException {
		CreateButton.click();
		Thread.sleep(4000);

	}

	public void Userregister(String frname ,String lsName ,String mobile,String psword) {

		FirstName.sendKeys(frname);
		LastName.sendKeys(lsName);
		MobNumber.sendKeys(mobile);
		UserPass.sendKeys(psword);
		Gender.click();

	}

	public void select_Day(String day) throws InterruptedException {
		
		Select s = new Select(Day);
		s.selectByVisibleText(day);

	}

	public void select_month(String month) throws InterruptedException {	

		Select s1 = new Select(Month);
		s1.selectByValue(month);	

	}

	public void select_year(String year) throws InterruptedException {

		Select s2 = new Select(Year);
		s2.selectByValue(year);

	}

	public void SignUp() throws InterruptedException {
		SignUp.click();
		Thread.sleep(5000);

	}

}
