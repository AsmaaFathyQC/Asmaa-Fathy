package Instabug.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class regiter extends testBase{

	registerpage registerobject;
	
	
	@Test
	
	public void User_register_positive() throws InterruptedException {
		driver = new ChromeDriver();
		driver.navigate().to("https://www.facebook.com/");
		registerobject = new registerpage(driver);
		registerobject.click_createbutton();
		registerobject.Userregister("asmaa", "sayed", "01118765960","1234asm_gg");
        registerobject.select_Day("11");
		registerobject.select_month("3");
		registerobject.select_year("1992");
		registerobject.SignUp();
		
	}
	@Test
    public void User_register_invalidname() throws InterruptedException {
		driver = new ChromeDriver();
		driver.navigate().to("https://www.facebook.com/");
		registerobject = new registerpage(driver);
		registerobject.click_createbutton();
		registerobject.Userregister("asmaa1111111____11", "", "01118765960","1234asm_gg");
        registerobject.select_Day("11");
		registerobject.select_month("3");
		registerobject.select_year("1992");
		registerobject.SignUp();
		
	}
	@Test
   public void User_register_invalidmobile() throws InterruptedException {
	driver = new ChromeDriver();
	driver.navigate().to("https://www.facebook.com/");
	registerobject = new registerpage(driver);
	registerobject.click_createbutton();
	registerobject.Userregister("asmaa", "sayed", "0160","1234asm_gg");
    registerobject.select_Day("11");
	registerobject.select_month("3");
	registerobject.select_year("1992");
	registerobject.SignUp();
	
}
	@Test
   public void User_register_invalidpassword() throws InterruptedException {
	driver = new ChromeDriver();
	driver.navigate().to("https://www.facebook.com/");
	registerobject = new registerpage(driver);
	registerobject.click_createbutton();
	registerobject.Userregister("asmaa", "sayed", "01110346780","1234");
    registerobject.select_Day("11");
	registerobject.select_month("3");
	registerobject.select_year("1992");
	registerobject.SignUp();
	
}
	
}
