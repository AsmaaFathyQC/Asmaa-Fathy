package Instabug.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import Instabug.Test.loginpage;
import Instabug.Test.pageBase;

public class Login  extends testBase{

	loginpage loginobject;
	@Test
	public void Userlogin_positive() {
		driver = new ChromeDriver();
		driver.navigate().to("https://www.facebook.com/");
		loginobject = new loginpage(driver);
		loginobject.Userlogin("kqwbiyfssk_1656007026@tfbnw.net","1234567890_asmaa");
		String ActualTitle = driver.getTitle();
		String ExpectedTitle = "Facebook";
		Assert.assertEquals(ExpectedTitle, ActualTitle);
		

	}
	@Test
	public void Userlogin_wrongemail() {

		driver = new ChromeDriver();
		driver.navigate().to("https://www.facebook.com/");
		loginobject = new loginpage(driver);
		loginobject.Userlogin("kqwbiyfssk_16566@tfbnw.net","1234567890_asmaa");
		
	
	}
	@Test
	public void Userlogin_wrongpass() {
		driver = new ChromeDriver();
		driver.navigate().to("https://www.facebook.com/");
		loginobject = new loginpage(driver);
		loginobject.Userlogin("kqwbiyfssk_1656007026@tfbnw.net","1290_asmaa");
		
		
	}
}
